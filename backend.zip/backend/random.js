// import and export statements 

// 1)default 
// 2) named


// 1)default
let something = ()=>{
    console.log("this is anything")
}

// export this 
// export default something


// 2)named

// export{something}


let a = 10

let name = "Vaibhavi "

export {something , a , name }