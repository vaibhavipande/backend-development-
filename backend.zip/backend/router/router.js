import express from "express"

import {GetHome,GetAbout, Get404,  GetServices} from "../controllers/controller.js"

let router = express()

router.get("/" , GetHome)

router.get("/about" , GetAbout)

router.get("/services" , GetServices)

router.get("*" , Get404)

export { router }