/// dependencies
import express from "express"
import dotenv from "dotenv"
import ejs from "ejs"

// configure .env file
dotenv.config({ path: './config.env'})

// middlewares 
import { router } from "./router/router.js"


// import {something , a , name } from "./random.js"


let port = process.env.PORT || 3020

const app = express()

// view

app.set("view engine","ejs")


// static folder
app.use(express.static("public"))


// router
app.use(router)


// local port 

// localhost:port   when you run on local host in brouser type "local host:____"

app.listen(port,()=>{
    console.log(`Server is Running On Port: http://localhost:${port} !`)
})