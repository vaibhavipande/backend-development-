let GetHome = (req,res) =>{
    let someData = "This is our backend development project"
    res.status(200).render("index.ejs", { someData, newData: "Vaibhavi" })
}

let GetAbout = (req,res) =>{
    res.status(200).render("about.ejs")
}

let GetServices = (req,res) =>{
    res.status(200).send("service.html")
}

let Get404 = (req,res) =>{
    res.status(404).send("Welcome to 404")
}

export { GetHome, GetAbout, GetServices, Get404}